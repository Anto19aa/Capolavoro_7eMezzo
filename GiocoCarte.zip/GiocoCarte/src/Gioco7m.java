public class Gioco7m {
    public static void main(String argv[]) {
        MezzoSette f = new MezzoSette();
        f.setTitle("Gioco del 7 e mezzo");
        f.setSize(600, 400);
        f.setVisible(true);
    }
}